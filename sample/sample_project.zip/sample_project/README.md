# Sample Project — The Awakening

This sample demonstrates how to structure an SQ Protocol-powered workflow. It includes:

- `scene.json`: creative intent and environment
- `permission.json`: agent capabilities and execution flow
- `cue_sheets/`: optional time-based cues for music and visuals

Use this to test integration between GPT, Suno, MJ, and Veo.
